import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import argparse
import time
import logging
from typing import Dict, Any, Optional
from multiprocessing import Pool
from app.ai.ataxx_env import AtaxxEnvironment
from app.ai.bot_trainer import get_bot_move

# Thiết lập logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Hàm tạo bàn cờ mặc định
def create_default_board() -> list:
    board = [['empty' for _ in range(7)] for _ in range(7)]
    board[0][0] = 'yellow'  # Yellow góc trên trái
    board[6][6] = 'yellow'  # Yellow góc dưới phải
    board[0][6] = 'red'  # Red góc trên phải
    board[6][0] = 'red'  # Red góc dưới trái
    return board

# Hàm chạy một trận đấu
def run_single_game(args: tuple) -> Dict[str, Any]:
    game_id, player1_algo, player2_algo, player1_iterations, player2_iterations = args
    logging.info(f"Bắt đầu trận {game_id} (Yellow: {player1_algo}, {player1_iterations} iters; Red: {player2_algo}, {player2_iterations} iters)")
    
    # Khởi tạo môi trường với bàn cờ mặc định
    env = AtaxxEnvironment(board_size=7)
    env.board = create_default_board()  # Đặt bàn cờ mặc định
    move_count = 0
    game_data = {
        "game_id": game_id,
        "winner": None,
        "player1_algo_time": 0.0,
        "player2_algo_time": 0.0,
        "yellow_score": 0,
        "red_score": 0,
        "move_count": 0
    }
    
    while not env.is_game_over():
        current_player = env.current_player
        algo = player1_algo if current_player == "yellow" else player2_algo
        iterations = player1_iterations if current_player == "yellow" else player2_iterations
        
        start_time = time.time()
        try:
            bot_result = get_bot_move(
                initial_board=env.board,
                current_player=current_player,
                algorithm=algo,
                iterations=iterations
            )
            move = bot_result["move"]
        except Exception as e:
            logging.error(f"Lỗi khi lấy nước đi cho {algo} trong trận {game_id}: {str(e)}")
            env.current_player = "red" if current_player == "yellow" else "yellow"
            continue
        end_time = time.time()
        
        if move is None:
            env.current_player = "red" if current_player == "yellow" else "yellow"
            continue
        
        if current_player == "yellow":
            game_data["player1_algo_time"] += end_time - start_time
        else:
            game_data["player2_algo_time"] += end_time - start_time
        
        env.make_move(move["from"], move["to"])
        move_count += 1
    
    if env.is_game_over():
        scores = env.calculate_scores()
        game_data["yellow_score"] = scores["yellowScore"]
        game_data["red_score"] = scores["redScore"]
        if scores["yellowScore"] > scores["redScore"]:
            game_data["winner"] = "yellow"
        elif scores["redScore"] > scores["yellowScore"]:
            game_data["winner"] = "red"
        else:
            game_data["winner"] = "draw"
    
    game_data["move_count"] = move_count
    logging.info(f"Kết thúc trận {game_id}: {game_data['winner']}")
    return game_data

# Hàm chạy thí nghiệm
def run_experiment(
    num_games: int = 10,
    player1_algo: str = "minimax",
    player2_algo: str = "mcts-fractional",
    player1_iterations: int = 50,
    player2_iterations: int = 50
) -> pd.DataFrame:
    """
    Chạy thí nghiệm Ataxx với thuật toán cố định, iterations riêng, và bàn cờ mặc định.

    Args:
        num_games: Số trận đấu.
        player1_algo: Thuật toán cho Yellow.
        player2_algo: Thuật toán cho Red.
        player1_iterations: Số lần mô phỏng/độ sâu cho Yellow.
        player2_iterations: Số lần mô phỏng/độ sâu cho Red.

    Returns:
        pd.DataFrame: Kết quả thí nghiệm.
    """
    valid_algorithms = [
        "minimax", "mcts-binary", "mcts-binary-dk",
        "mcts-fractional", "mcts-fractional-dk", "mcts-minimax", "random"
    ]
    if player1_algo not in valid_algorithms:
        raise ValueError(f"Thuật toán {player1_algo} không hợp lệ. Chọn từ {valid_algorithms}")
    if player2_algo not in valid_algorithms:
        raise ValueError(f"Thuật toán {player2_algo} không hợp lệ. Chọn từ {valid_algorithms}")

    start_time = time.time()
    logging.info(f"Bắt đầu thí nghiệm với {num_games} trận (Yellow: {player1_algo}, {player1_iterations} iters; Red: {player2_algo}, {player2_iterations} iters)")
    
    # Chạy song song các trận
    with Pool(processes=4) as pool:
        args = [(i, player1_algo, player2_algo, player1_iterations, player2_iterations) for i in range(num_games)]
        results = pool.map(run_single_game, args)
    
    df = pd.DataFrame(results)
    logging.info(f"Hoàn thành thí nghiệm trong {time.time() - start_time:.2f} giây")
    return df

# Phân tích kết quả
def analyze_results(df: pd.DataFrame, player1_algo: str, player2_algo: str):
    """
    Phân tích kết quả thí nghiệm.

    Args:
        df: DataFrame chứa kết quả thí nghiệm.
        player1_algo: Thuật toán của Yellow.
        player2_algo: Thuật toán của Red.
    """
    # Tỷ lệ thắng
    win_counts = df["winner"].value_counts()
    total_games = len(df)
    yellow_wins = win_counts.get("yellow", 0) / total_games
    red_wins = win_counts.get("red", 0) / total_games
    draws = win_counts.get("draw", 0) / total_games
    print(f"Tỷ lệ thắng (Yellow: {player1_algo} vs Red: {player2_algo}):")
    print(f"Yellow thắng: {yellow_wins:.3f}")
    print(f"Red thắng: {red_wins:.3f}")
    print(f"Hòa: {draws:.3f}")
    
    # Thời gian chạy trung bình
    time_stats = {
        "algorithm": [player1_algo, player2_algo],
        "mean_time": [
            df["player1_algo_time"].mean(),
            df["player2_algo_time"].mean()
        ],
        "std_time": [
            df["player1_algo_time"].std(),
            df["player2_algo_time"].std()
        ]
    }
    time_df = pd.DataFrame(time_stats)
    print("\nThời gian chạy trung bình (giây):\n", time_df[["algorithm", "mean_time", "std_time"]])
    
    # Điểm trung bình
    score_stats = {
        "player": ["Yellow", "Red"],
        "mean_score": [
            df["yellow_score"].mean(),
            df["red_score"].mean()
        ],
        "std_score": [
            df["yellow_score"].std(),
            df["red_score"].std()
        ]
    }
    score_df = pd.DataFrame(score_stats)
    print("\nĐiểm trung bình:\n", score_df[["player", "mean_score", "std_score"]])
    
    # Số bước đi trung bình
    move_stats = {
        "metric": ["Move Count"],
        "mean": [df["move_count"].mean()],
        "std": [df["move_count"].std()]
    }
    move_df = pd.DataFrame(move_stats)
    print("\nSố bước đi trung bình:\n", move_df[["metric", "mean", "std"]])
    
    # Vẽ biểu đồ
    plt.figure(figsize=(20, 4))
    
    plt.subplot(1, 5, 1)
    plt.bar(["Yellow", "Red", "Draw"], [yellow_wins, red_wins, draws], color=["yellow", "red", "gray"])
    plt.title(f"Win Rate\nYellow ({player1_algo}) vs Red ({player2_algo})")
    plt.ylabel("Proportion")
    
    plt.subplot(1, 5, 2)
    plt.bar(time_df["algorithm"], time_df["mean_time"])
    plt.title("Thời gian chạy trung bình")
    plt.ylabel("Seconds")
    
    plt.subplot(1, 5, 3)
    plt.bar(score_df["player"], score_df["mean_score"], color=["yellow", "red"])
    plt.title("Điểm trung bình")
    plt.ylabel("Score")
    
    plt.subplot(1, 5, 4)
    plt.bar(move_df["metric"], move_df["mean"], color="green")
    plt.title("Số bước đi trung bình")
    plt.ylabel("Moves")
    
    plt.subplot(1, 5, 5)
    plt.hist(df["move_count"], bins=10, color="green", alpha=0.7)
    plt.title("Phân phối số bước đi")
    plt.xlabel("Moves")
    plt.ylabel("Frequency")
    
    plt.tight_layout()
    plt.savefig("/kaggle/working/ataxx_default_board_results.png")
    plt.show()

# Hàm chính
def main():
    parser = argparse.ArgumentParser(description="Chạy thí nghiệm Ataxx với bàn cờ mặc định, điểm số, số bước đi, và iterations riêng trên Kaggle")
    parser.add_argument(
        "--player1-algo",
        type=str,
        default="minimax",
        choices=[
            "minimax", "mcts-binary", "mcts-binary-dk",
            "mcts-fractional", "mcts-fractional-dk", "mcts-minimax", "random"
        ],
        help="Thuật toán cho Yellow"
    )
    parser.add_argument(
        "--player2-algo",
        type=str,
        default="mcts-minimax",
        choices=[
            "minimax", "mcts-binary", "mcts-binary-dk",
            "mcts-fractional", "mcts-fractional-dk", "mcts-minimax", "random"
        ],
        help="Thuật toán cho Red"
    )
    parser.add_argument("--num-games", type=int, default=20, help="Số trận đấu")
    parser.add_argument("--player1-iterations", type=int, default=50, help="Số lần mô phỏng/độ sâu cho Yellow")
    parser.add_argument("--player2-iterations", type=int, default=100, help="Số lần mô phỏng/độ sâu cho Red")
    args = parser.parse_args(args=[])  # Trong Kaggle, bỏ args để chỉnh thủ công
    
    print(f"Bắt đầu thí nghiệm Ataxx với bàn cờ mặc định: Yellow ({args.player1_algo}, {args.player1_iterations} iters) vs Red ({args.player2_algo}, {args.player2_iterations} iters)")
    df = run_experiment(
        num_games=args.num_games,
        player1_algo=args.player1_algo,
        player2_algo=args.player2_algo,
        player1_iterations=args.player1_iterations,
        player2_iterations=args.player2_iterations
    )
    df.to_csv("/kaggle/working/ataxx_default_board_results.csv", index=False)
    print("Đã lưu kết quả vào /kaggle/working/ataxx_default_board_results.csv")
    
    # analyze_results(df, args.player1_algo, args.player2_algo)

if __name__ == "__main__":
    main()